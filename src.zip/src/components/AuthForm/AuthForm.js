import React from "react";
import logo from '../../images/logo.svg'
import { Link } from "react-router-dom";

function AuthForm(props) {
    return (
        <div className="authForm">
            <div className="authForm__welcome-box">
                <Link to="/" className="authForm__logo"></Link>
                <p className="authForm__welcome">{props.welcomeText}</p>
            </div>
            <form className="authForm__form">
                <ul className="authForm__list">
                    {props.location.pathname === "/signup" && (
                    <li className="authForm__item">
                        <label className="authForm__label" htmlFor="name">Имя</label>
                        <input id="name" name="name" type="text" className="authForm__input"></input>
                        <span className="authForm__error"></span>
                    </li>  
                    )}
                    <li className="authForm__item">
                        <label className="authForm__label" htmlFor="email">E-mail</label>
                        <input id="email" name="email" type="email" className="authForm__input"></input>                
                        <span className="authForm__error"></span>
                    </li>
                    <li className="authForm__item">
                        <label className="authForm__label" htmlFor="password">Пароль</label>
                        <input id="password" name="password" type="password" className="authForm__input"></input>
                        <span className="authForm__error"></span>
                    </li>
                </ul>
                <button className="authForm__button" type="submit">{props.buttonText}</button>
                <p className="authForm__quest">{props.question} <Link to={props.linkTo} className="authForm__link">{props.linkText}</Link></p>
            </form>
        </div>
    )
}

export default AuthForm;