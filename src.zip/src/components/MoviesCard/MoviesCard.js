import React from "react";
import { CurrentUserContext } from "../../context/CurrentUserContext";

function MoviesCard(props) {
  // const currentUser = React.useContext(CurrentUserContext);
  // const isSaved = props.owner === currentUser._id;
  const isSaved = props.ownMovies.some((movie) => movie.movieId === props.id);

  return (
    <li className="movies__card">
        <div className="movies__poster">
            <img src={`https://api.nomoreparties.co${props.image.url}`} alt="Поиск" className="movies__img"/>
            <div className="movies__overlay">
              <a className="movies__trailer-link" href={props.trailerLink} target="_blank" rel="noopener noreferrer"></a>
              {props.location.pathname === "/movies" ? (
                <button className={isSaved ? "movies__saved-button" : "movies__save-button"} onClick={props.toggleSaveButton}></button>
              ):(
                <button className="movies__delete-button" onClick={props.removeMovie}></button>
              )}
            </div>
        </div>
        <div className="movies__title">
            <p className="movies__name">{props.nameRU}</p>
            <p className="movies__duration">{Math.floor(props.duration / 60)}ч {props.duration % 60}м</p>
        </div>
    </li>
  );
}

export default MoviesCard;
