import React from "react";
import AuthForm from "../AuthForm/AuthForm";

function Register(props) {
    return (
        <>
        <AuthForm 
            welcomeText="Добро пожаловать!"
            buttonText="Зарегистрироваться"
            question="Уже зарегистрированы?"
            linkText="Войти"
            linkTo="/signin"
            location={props.location}
        />
        </>
    )
}

export default Register;