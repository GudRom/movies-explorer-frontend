import React from "react";
import SearchForm from '../SearchForm/SearchForm';
import MoviesCardList from '../MoviesCardList/MoviesCardList';

function SavedMovies(props) {
    return (
    <>
        <SearchForm 
        inputTitle={props.inputTitle}
        setInputTitle={props.setInputTitle}
        getMoviesCard={props.getMoviesCard}
        setInfoText={props.setInfoText}
        check={props.check}
        setCheck={props.setCheck}
        />
        <MoviesCardList
        movies={props.movies}
        inputTitle={props.inputTitle}    
        infoText={props.infoText}
        preloader={props.preloader}
        >
            <ul className="movies__list">
                {props.ownMovies.map((item) => (
                    <MoviesCard
                        key={item.id}
                        {...item}
                        location={props.location}
                        removeMovie={props.removeMovie}
                    />
                ))}
            </ul>
        </MoviesCardList>
    </>
    )
}

export default SavedMovies;
