import React from "react";
import AuthForm from "../AuthForm/AuthForm";

function Login(props) {
    return (
        <>
        <AuthForm 
            welcomeText="Рады видеть!"
            buttonText="Войти"
            question="Еще не зарегистрированы?"
            linkText="Регистрация"
            linkTo="/signup"
            location={props.location}
        />
        </>
    )
}

export default Login;