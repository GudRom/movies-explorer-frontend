import React from "react";

function Portfolio() {
    return (
    <div className="portfolio">
        <h3 className="portfolio__header">Портфолио</h3>
        <ul className="portfolio__list">
            <li className="portfolio__item">
                <a href="https://github.com/GudRom" className="portfolio__name">Статичный сайт</a>
                <a href="https://github.com/GudRom" className="portfolio__link"></a>
            </li>
            <li className="portfolio__item">
                <a href="https://github.com/GudRom" className="portfolio__name">Адаптивный сайт</a>
                <a href="https://github.com/GudRom" className="portfolio__link"></a>
            </li>
            <li className="portfolio__item">
                <a href="https://github.com/GudRom" className="portfolio__name">Одностраничное приложение</a>
                <a href="https://github.com/GudRom" className="portfolio__link"></a>
            </li>
        </ul>
    </div>
    )
}

export default Portfolio;
