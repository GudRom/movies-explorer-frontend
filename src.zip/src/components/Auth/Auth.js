import React from "react";
import { Link } from "react-router-dom";
import { useFormWithValidation } from "../../utils/Validator";

function Auth(props) {
    const { formData, handleChange, errors, isValid, resetForm } = useFormWithValidation();
    function handleSubmitReg(evt) {
        evt.preventDefault();
        props.handleRegistration(formData);
    }

    function handleSubmitLog(evt) {
        evt.preventDefault();
        props.handleLogin(formData);
        resetForm();
    }
    return (
        <div className="auth">
            <div className="auth__welcome-box">
                <Link to="/" className="auth__logo"></Link>
                <p className="auth__welcome">{props.welcomeText}</p>
            </div>
            <form className="auth__form" onSubmit={props.location.pathname === "/signup" ? handleSubmitReg : handleSubmitLog}>
                <ul className="auth__list">
                    {props.location.pathname === "/signup" && (
                    <li className="auth__item">
                        <label className="auth__label" htmlFor="name">Имя</label>
                        <input id="name" name="name" type="text" className="auth__input" required onChange={handleChange} value={formData.name}></input>
                        {errors.name !== "" && <span className="auth__error">{errors.name}</span>}
                    </li>  
                    )}
                    <li className="auth__item">
                        <label className="auth__label" htmlFor="email">E-mail</label>
                        <input id="email" name="email" type="email" className="auth__input" required onChange={handleChange} value={formData.email}></input>
                        {errors.email !== "" && <span className="auth__error">{errors.email}</span>}
                    </li>
                    <li className="auth__item">
                        <label className="auth__label" htmlFor="password">Пароль</label>
                        <input id="password" name="password" type="password" className={`auth__input ${props.authMessage !== "" && "auth__input_red"}`} required onChange={handleChange} value={formData.password}></input>
                        {errors.password !== "" && <span className="auth__error">{errors.password}</span>}
                        {props.authMessage !== "" && <span className="auth__error">{props.authMessage}</span>}
                    </li>
                </ul>
                {isValid ? (
                    <button className="auth__button" type="submit">{props.buttonText}</button>
                ) : (
                    <button className="auth__button" type="submit" disabled>{props.buttonText}</button>
                )}
                <p className="auth__quest">{props.question} <Link to={props.linkTo} className="auth__link">{props.linkText}</Link></p>
            </form>
        </div>
    )
}

export default Auth;