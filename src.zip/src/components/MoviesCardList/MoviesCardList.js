import React from "react";
import Preloader from '../Preloader/Preloader'

function MoviesCardlist(props) {
    return (
    <section className="movies">
      {props.preloader ? (
        <Preloader />
      ) : (
        <>
        {props.infoText !== "" ? (
          <p className="movies__error">{props.infoText}</p>
        ) : (
          props.children
        ) 
        }
        </>
      )}
    </section>
    )
}

export default MoviesCardlist;