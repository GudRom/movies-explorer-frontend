import React from "react";
import { Link } from "react-router-dom";

function Header(props) {
    return (
        <>
        <header className="header">
            <Link to="/" className="header__logo" />
            {props.location.pathname !== "/" ? (
                <>
                <nav className="header__navigation">
                    <ul className="header__list">
                        <Link to="/movies" className={`header__link ${props.location.pathname === "/movies" && "header__link_active"}`}>Фильмы</Link>
                        <Link to="/saved-movies" className={`header__link ${props.location.pathname === "/saved-movies" && "header__link_active"}`}>Сохранённые фильмы</Link>
                    </ul>
                    <Link to="/profile" className="header__account-button">Аккаунт</Link>
                </nav> 
                <button className="header__menu-button" onClick={props.onOpenPopup}></button>
                </>
            ) : (
                <nav className="header__navigation">
                    <ul className="header__list">
                        <Link to="/signup" className="header__link">Регистрация</Link>
                    </ul>
                <Link to="/signin" className="header__login-button">Войти</Link>
                </nav> 
            )}
        </header>
        </>
    )
}

export default Header;
