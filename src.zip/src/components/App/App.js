import React from 'react';
import { Route, Routes, Navigate, useNavigate, useLocation } from "react-router-dom";
import { CurrentUserContext } from "../../context/CurrentUserContext";
import Header from '../Header/Header';
import Main from '../Main/Main';
import Movies from '../Movies/Movies';
import SavedMovies from '../SavedMovies/SavedMovies';
import Profile from '../Profile/Profile';
import Login from '../Login/Login';
import Register from '../Register/Register';
import PageNotFound from '../PageNotFound/PageNotFound'
import Footer from '../Footer/Footer';
import Navigation from '../Navigation/Navigation';
import filterSearch from '../../utils/FilterSearch';
import beatFilmApi from '../../utils/MoviesApi';
import api from '../../utils/MainApi';
import ProtectedRoute from '../../utils/ProtectedRoute';


function App() {
  const location = useLocation();
  const navigate = useNavigate();
  const [isMenuPopupOpen, setIsMenuPopupOpen] = React.useState(false);
  const [currentUser, setCurrentUser] = React.useState({});
  const [loggedIn, setLoggedIn] = React.useState(false);
  const [movies, setMovies] = React.useState([]);  
  const [ownMovies, setOwnMovies] = React.useState([]);
  const [inputTitle, setInputTitle] = React.useState("");
  const [check, setCheck] = React.useState(false);
  const [infoText, setInfoText] = React.useState("");
  const [preloader, setPreloader] = React.useState(false);
  const [gridColumns, setGridColumns] = React.useState(3);
  const [gridRows, setGridRows] = React.useState(4);
  const [authMessage, setAuthMessage] = React.useState("")
  const lastCard = gridColumns * gridRows;
  const pathWithHeader = [
    '/',
    '/profile',
    '/movies',
    '/saved-movies',
  ]
  const pathWithFooter = [
    '/',
    '/movies',
    '/saved-movies',
  ]
  // Слушатель изменения размера экрана
  React.useEffect(() => {
    window.addEventListener('resize', getColumns);

    return () => {
      window.removeEventListener('resize', getColumns);
    }
  }, [])

  React.useEffect(() => {
    setInputTitle(JSON.parse(localStorage.inputTitle));
    setCheck(JSON.parse(localStorage.check));
    setMovies(JSON.parse(localStorage.foundMovies));
  }, [])

  React.useEffect(() => {
    if (localStorage.getItem("jwt")) {
      api
      .checkToken()
      .then((res) => {
        if (res) {
          setLoggedIn(true);
        }
      });
    }
  }, [loggedIn]);

  // Считаем количество столбцов и записываем в стейт
  function getColumns() {
    const grid = document.querySelector('.movies__list');
    const columns = window.getComputedStyle(grid).getPropertyValue("grid-template-columns").split(" ").length;
    setGridColumns(columns);
    window.innerWidth < 500 && setGridRows(5);
  }

  function getCurrentCards(arrMovies) {
      console.log(lastCard);
      console.log(arrMovies.length)
      return arrMovies.slice(0, lastCard);
  }

  // Кнопка еще
  function getMore() {
    if (gridColumns === 1) {
      setGridRows(gridRows + 2);
    } else {
      setGridRows(gridRows + 1);
    }
  }

  // Фильтруем и отдаем результат. 
  function searchMoviesCard() {
    localStorage.setItem('check', JSON.stringify(check));
    localStorage.setItem('inputTitle', JSON.stringify(inputTitle));
    const searchRes = filterSearch(
      JSON.parse(localStorage.movie),
      JSON.parse(localStorage.inputTitle),
      JSON.parse(localStorage.check));
    setPreloader(false);
    if (searchRes.length !== 0) {
      setMovies(searchRes);
      localStorage.setItem('foundMovies', JSON.stringify(searchRes));
      getColumns();
      setInfoText("");
    } else {
      setInfoText("Ничего не найдено");
    }   
  }

  // Получаем фильмы со стороннего Api.
  function getMoviesCard() {
    setPreloader(true);
    if (localStorage.movie === null) {
    beatFilmApi
      .getMovies()
      .then((movie) => {
        localStorage.setItem('movie', JSON.stringify(movie));
        searchMoviesCard();
      })
      .catch((err) => {
        console.log(err);
        setInfoText("Во время запроса произошла ошибка. Возможно, проблема с соединением или сервер недоступен. Подождите немного и попробуйте ещё раз");
      });
    } else {
      searchMoviesCard();
      console.log(movies)
    }
  }
  
  function getSavedMoviesCard() {
    setPreloader(true);
    api
      .getMovies()
      .then((movie) => {
        localStorage.setItem('savedMovies', JSON.stringify(movie, inputTitle, check));
        const searchRes = filterSearch(JSON.parse(localStorage.getItem('savedMovie')));
        if (searchRes.length !== 0) {
          setOwnMovies(searchRes);
          getColumns();
          setInfoText("");
        } else {
          setInfoText("Ничего не найдено");
        }
        setPreloader(false);
      })
      .catch((err) => {
        console.log(err);
        setInfoText("Во время запроса произошла ошибка. Возможно, проблема с соединением или сервер недоступен. Подождите немного и попробуйте ещё раз");
      });
  }

  function saveMovie(movie) {
    // Отправляем запрос в API и сохраняем фильм в нашу базу
    api
      .addMovie(movie)
      .then((newMovie) => {
        setOwnMovies(newMovie);
      })
      .catch((err) => console.log(err));
  }

  function removeMovie(movie) {
    // Отправляем запрос в API и удаляем фильм, создаем копию массива, исключив удаленную карточку
    api
      .deleteCard(movie.id)
      .then(() => {
        setOwnMovies((state) => state.filter((c) => c.movieId !== movie.id));
      })
      .catch((err) => console.log(err));
  }

  function toggleSaveButton(movie) {
    const isSaved = ownMovies.some((film) => film.movieId === movie.id);
    if (!isSaved) {
      saveMovie(movie);
    } else {
      removeMovie(movie);
    }
  }

  function handleMenuPopupClick() {
    setIsMenuPopupOpen(true);
  }

  function closePopup() {
    setIsMenuPopupOpen(false);
  }



  function handleRegistration(formData) {
    api
      .register(formData.name, formData.email, formData.password)
      .then(() => {
        handleLogin(formData);
      })
      .catch((err) => {
        console.log(err);
        setAuthMessage(err.message);
        console.log(authMessage);
      });
  }

  function handleLogin(formData) {
    api
      .authorize(formData.email, formData.password)
      .then((data) => {
        localStorage.setItem('jwt', data.jwt);
        getUserInfo();
        setLoggedIn(true);        
        console.log(currentUser);
        navigate("/movies")
      })
      .catch((err) => {
        console.log(err);
        setAuthMessage(err.message);
        console.log(authMessage);
      });
  }

  function getUserInfo() {
    api
      .getUserInfo()
      .then((info) => {
        console.log(info);
        setCurrentUser(info);
      })
      .catch((err) => console.log(err));
  }

  function updateUserInfo(token) {
    api
      .updateProfile(token)
      .then((info) => {
        setCurrentUser(info)
      })
      .catch((err) => console.log(err));
  }


  function logout() {
    setMovies([]);
    setCurrentUser({});
    localStorage.removeItem('movies');
    localStorage.removeItem('foundMovies');
    localStorage.removeItem('inputTitle');
    localStorage.removeItem('check');
    setLoggedIn(false);
    localStorage.removeItem('jwt');
    navigate("/");
  }

  return (
    <>
    <CurrentUserContext.Provider value={currentUser}>
      {pathWithHeader.includes(location.pathname) && (<Header 
        location={location}
        loggedIn={loggedIn}
        isOpen={isMenuPopupOpen}
        onOpenPopup={handleMenuPopupClick}
      />)}
      <Routes>
        <Route path="/" 
          element={
            <Main />
          }
        />
          <Route path="/movies"
            element={
              <ProtectedRoute loggedIn={loggedIn}>
                <Movies 
                  movies={getCurrentCards(movies)}
                  ownMovies={ownMovies}
                  location={location}
                  inputTitle={inputTitle}
                  setInputTitle={setInputTitle}
                  getMoviesCard={getMoviesCard}
                  setInfoText={setInfoText}
                  setCheck={setCheck}
                  check={check}
                  infoText={infoText}
                  preloader={preloader}
                  getMore={getMore}
                  toggleSaveButton={toggleSaveButton}
                />
                <Navigation 
                  isOpen={isMenuPopupOpen}
                  onClose={closePopup}
                  location={location}
                />
              </ProtectedRoute>
            }
          />
          <Route path="/saved-movies"
            element={
              <ProtectedRoute loggedIn={loggedIn}>
                <SavedMovies             
                  movies={movies}
                  ownMovies={getCurrentCards(ownMovies)}
                  location={location}
                  inputTitle={inputTitle}
                  setInputTitle={setInputTitle}
                  getMoviesCard={getSavedMoviesCard}
                  setInfoText={setInfoText}
                  setCheck={setCheck}
                  check={check}
                  infoText={infoText}
                  preloader={preloader}
                  getMore={getMore}
                  lastCard={lastCard}
                  removeMovie={removeMovie}
                />
                <Navigation 
                  isOpen={isMenuPopupOpen}
                  onClose={closePopup} 
                  location={location}
                />
              </ProtectedRoute>
            }
          />
          <Route path="/profile"
            element={              
              <ProtectedRoute loggedIn={loggedIn}>
                <Profile 
                  logout={logout}
                  updateUserInfo={updateUserInfo} />
                <Navigation 
                  isOpen={isMenuPopupOpen}
                  onClose={closePopup}
                  location={location}
                />
              </ProtectedRoute>
            }
          />
        <Route path="/signin"
          element={
            loggedIn ? <Navigate to="/" /> : <Login
              location={location}
              authMessage={authMessage}
              handleLogin={handleLogin} 
            />
          }
        />
        <Route path="/signup"
          element={
            loggedIn ? <Navigate to="/" /> : <Register
              location={location}
              authMessage={authMessage}
              handleRegistration={handleRegistration} 
            />
          }
        />
        <Route path="*"
          element={
            <PageNotFound />
          }
        />
      </Routes>
      {pathWithFooter.includes(location.pathname) && (<Footer />)}
      </CurrentUserContext.Provider>
    </>
  );
}

export default App;
