import React from "react";
import UniversalHeader from '../UniversalHeader/UniversalHeader';

function AboutProject() {
    return (
    <section className="project">
        <UniversalHeader header="О проекте"/>
        <div className="project__flexbox">
            <div className="project__textblock">
                <p className="project__header">Дипломный проект включал 5&nbsp;этапов</p>
                <p className="project__text">Составление плана, работу над бэкендом, вёрстку, добавление функциональности и&nbsp;финальные доработки.</p>
            </div>
            <div className="project__textblock">
                <p className="project__header">На выполнение диплома ушло 5&nbsp;недель</p>
                <p className="project__text">У&nbsp;каждого этапа был мягкий и&nbsp;жёсткий дедлайн, которые нужно было соблюдать, чтобы успешно защититься.</p>
            </div>
        </div>
        <div className="project__timeline">
            <div className="project__flex-basis">
                <div className="project__oneweek">1 неделя</div>
                <div className="project__fourweek">4 недели</div>
            </div>
            <div className="project__flex-basis">
                <div className="project__caption-back">Back-end</div>
                <div className="project__caption-front">Front-end</div>
            </div>
        </div>
    </section>
    )
}

export default AboutProject;
