import React from "react";
import { CurrentUserContext } from "../../context/CurrentUserContext";
import { useFormWithValidation } from "../../utils/Validator";

function Profile(props) {    
  const currentUser = React.useContext(CurrentUserContext);
  const { formData, handleChange, errors, isValid, setFormData } = useFormWithValidation();

  React.useEffect(() => {
    setFormData({name: currentUser.name});
    setFormData({email: currentUser.email});
  }, [currentUser]);

  const handleSubmit = (evt) => {
      evt.preventDefault();
      props.updateUserInfo();
  }

    return (
        <div className="profile">
            <p className="profile__welcome">Привет, {formData.name || "друг"}!</p>
            <form className="profile__form" onSubmit={handleSubmit}>
                <div className="profile__input-box">
                    <label className="profile__label" htmlFor="profile-name">Имя</label>
                    <input type="text" className="profile__input" id="profile-name" onChange={handleChange} value={formData.name || ""} />                
                    {errors.name !== "" && <span className="profile__error">{errors.name}</span>}
                </div>
                <div className="profile__line"></div>
                <div className="profile__input-box">
                    <label className="profile__label" htmlFor="profile-email">E-mail</label>
                    <input type="email" className="profile__input" id="profile-email" onChange={handleChange} value={formData.email || ""} />
                    {errors.email !== "" && <span className="profile__error">{errors.email}</span>}
                </div>
                {isValid ? (
                <button type="submit" className="profile__edit-button">Редактировать</button>
                ) : (
                <button type="submit" className="profile__edit-button" disabled>Редактировать</button>
                )}
            </form>
            <button className="profile__button" onClick={props.logout} >Выйти из аккаунта</button>
        </div>
    )
}

export default Profile;