import React from 'react';
import { Navigate } from "react-router-dom";

function ProtectedRoute({ children, loggedIn }) {
  if (loggedIn){
    return children;
  }

  return <Navigate to="/movies" />
}

export default ProtectedRoute;