import React, { useCallback } from "react";

//хук управления формой
// export function useForm() {
//   const [formData, setFormData] = React.useState({
//     name:'',
//     email:'',
//     password:''
//   });

//   const handleChange = (evt) => {
//     const {name, value} = evt.target;
//     setFormData({...formData, [name]: value});
//   };

//   return {formData, handleChange, setFormData};
// }

//хук управления формой и валидации формы
export function useFormWithValidation() {
  const [formData, setFormData] = React.useState({
    name:'',
    email:'',
    password:''
  });
  const [errors, setErrors] = React.useState({
    name:'',
    email:'',
    password:''
  });
  const [isValid, setIsValid] = React.useState(false);

  const handleChange = (evt) => {
    const target = evt.target;
    const name = target.name;
    const value = target.value;
    setFormData({...formData, [name]: value});
    setErrors({...errors, [name]: target.validationMessage });
    setIsValid(target.closest("form").checkValidity());
  };

  const resetForm = useCallback(
    (newValues = {}, newErrors = {}, newIsValid = false) => {
      setFormData(newValues);
      setErrors(newErrors);
      setIsValid(newIsValid);
    },
    [setFormData, setErrors, setIsValid]
  );

  return { formData, handleChange, errors, isValid, resetForm, setFormData };
}